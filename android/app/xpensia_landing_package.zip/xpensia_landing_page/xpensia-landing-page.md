# 💸 Xpensia — The Smart Way to Track Your Spending

**No more manual tracking. No confusing spreadsheets.  
Just forward your SMS and let Xpensia do the rest.**

---

## 📱 What Xpensia Does

✅ Automatically extracts transactions from your bank SMS  
✅ Categorizes your expenses & income smartly  
✅ Gives you insights, trends, and monthly summaries  
✅ Private by design — no account linking or sensitive access  
✅ Built for MENA: supports Arabic, multi-currency, and local formats

---

## ✨ Key Features

- 🔍 SmartPaste: Turn SMS into clean, categorized records  
- 📊 Personal Finance Dashboard: Know where your money goes  
- 🏦 Multi-Account Support: Cash, banks, crypto, even gold  
- 🔔 Budget Alerts (Coming Soon)  
- 🔐 Offline-first. Your data stays on your device

---

## 📷 Screenshots

*(Add 3–4 preview images of SmartPaste, Dashboard, Add Transaction, etc.)*

---

## 📥 Join the Beta / Get the App

- [ ] 🔗 Google Play Store (link here)  
- [ ] 🔗 Apple App Store (pending / link)  
- [ ] 📬 Want early access or updates? [Subscribe here](#)

---

## 📜 Privacy Comes First

We don’t store your data.  
We don’t send your SMS anywhere.  
Everything is processed on your device.

Read our [Privacy Policy](#) and [Terms of Use](#)

---

## 🧑‍💻 About the Maker

Xpensia is crafted by **Ahmed Abdellatief**, a finance-savvy tech builder based in Riyadh.  
This is not a startup experiment — it’s a real tool built to solve a real problem.

[LinkedIn](https://linkedin.com/in/...) • [Twitter](https://twitter.com/...) • [Contact](mailto:you@example.com)

---

## 💬 Feedback or Bug?

Found something weird? Have an idea?  
[→ Submit Feedback](#)

---

🚀 Xpensia — Less time tracking, more time living.
