const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BM8Jtt_b.js","assets/index-Clrk7wLB.js","assets/index-CypMzO6Y.css"])))=>i.map(i=>d[i]);
import{r as t,_ as e}from"./index-Clrk7wLB.js";const o=t("CapacitorUpdater",{web:()=>e(()=>import("./web-BM8Jtt_b.js"),__vite__mapDeps([0,1,2])).then(r=>new r.CapacitorUpdaterWeb)});export{o as CapacitorUpdater};
